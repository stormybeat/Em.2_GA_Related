  
1a: This includes being respectful of the @Closed DMS and @Ask to DM roles. Furthermore do not DM moderators over server issues. Instead please go to ⁠contact-staff.

1b: No calling testosterone or estrogen a poison and no non-consensual body trading jokes. 

1c: Statements about being watched, "not alone," or similar, or any statement/joke/etc designed to cause fear are not allowed. This includes "I am in your walls" type jokes.