8a: Sex jokes and the mention of Sex is banned

8b: This includes any horny behavior and jokes, or any action that could be interpreted as such.

8d: The mention of cum, genitals, and sexual/horny terminology are included in this ban.

8e: This includes no nipples regardless of gender. 8f: Any mention of tops, bottoms, switches, doms, subs terminology in their sexual definitions or any action that could be interpreted as such are banned.

8g: Because of discords [Members List Recent Activity](https://support.discord.com/hc/en-us/articles/22045487931799-Members-List-Recent-Activity-FAQ) any activity of an NSFW game you have on your profile will be treated the same as having an NSFW profile picture or NSFW name as it can be seen on the sidebar which minors can see. This will be met with a warn to your profile letting you know to fix it, but without a timeout. 
8g1: For example playing "Hentai Heaven" will get you warned, but GTA5 won't. 
8g2: For example playing "PornHub" will get you warned, but Call of Duty won't. 

8h: All content in profiles that sells, advertises, mentions, or solicits adult content will be grounds for a ban. Use above mentioned examples to define adult content. 

8i: Cropped NSFW content is strictly forbidden. NSFW includes gore, hentai, porn.