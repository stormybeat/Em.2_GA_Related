
### No Doxing or Sharing Personal Info

Sharing personal information of any user without their consent is strictly prohibited. This includes real names, addresses, contact details, or any other private information.