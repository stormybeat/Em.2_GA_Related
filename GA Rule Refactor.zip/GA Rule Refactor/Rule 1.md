
### Be civil and respectful.

Treat others with kindness and respect at all times. Do not lie about your age. Avoid offensive behavior, personal attacks, and disrespectful language. Disagreements are acceptable, but keep discussions constructive and avoid being overly confrontational. [[Rule 1 Clarifications]]
