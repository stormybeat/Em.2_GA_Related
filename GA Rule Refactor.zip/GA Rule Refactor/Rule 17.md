### Do not bypass auto-mod.
This server uses auto-mod to block messages deemed nsfw, violent, or triggering. Do not circumvent the auto-mod. [[Rule 17 Clarifications]]
