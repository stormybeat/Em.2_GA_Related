
### Moderator have discretion to do what they see fit.

If you're misbehaving, but it's not against any single rule, mods may take any action they see fit, within reason. If you believe a moderator has used this to abuse their power, please #contact-staff 