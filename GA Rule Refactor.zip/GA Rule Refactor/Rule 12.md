### Do not impersonate anyone.

It can cause others to become uncomfortable. Additionally users should be allowed to control their own image. 
#### As one of two exceptions on this list, if you'd like to for a joke, please ASK that member first! 