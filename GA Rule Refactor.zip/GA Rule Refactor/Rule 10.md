
### No spam.

Please do not spam within the server. This includes spam pinging members and roles.
