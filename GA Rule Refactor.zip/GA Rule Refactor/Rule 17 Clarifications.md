
17a. Bypassing auto-mod will result in a mute of 2+1n hours, where n is the number of prior actions that have been taken on you.