### Be Honest

Please do not spread lies. This includes lying about your age, or other traits about you.

#### This has the exception of the {Lies} channel!