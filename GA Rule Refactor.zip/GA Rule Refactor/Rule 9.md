
### Please keep all channels on-topic.

Please keep topics in a channel within the general theme of the channel. This includes venting staying within the venting channels.
Topics about ||eating disorders, suicide, and self harm,|| are strictly prohibited for the safety of members. 

