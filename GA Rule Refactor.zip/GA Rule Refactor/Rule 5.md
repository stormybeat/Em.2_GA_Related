
### No Breaking [Discord TOS](https://dis.gd/tos ) or [Community Guidelines](https://dis.gd/guidelines )

Being under 13 is [not allowed](https://support.discord.com/hc/en-us/articles/360040724612-Why-is-Discord-asking-for-my-birthday ). Furthermore discussions or sharing of any illegal content, including but not limited to malicious software, illegal drugs, or any other illicit activities, are also not allowed in the server.