
### Keep all conversations in English.

Short phrases or jokes in another language are allowed, but we cannot effectively moderate non-English extensive discussions.