
### No spam or self promotion.

Do not flood the server with irrelevant or repetitive messages. Self-promotion, such as sharing links or content related to external products or services, is only allowed if explicitly approved by the server administrators. This includes the promotion or offering invites to other discord servers. Even if you yourself don't own it. It still is promoting another discord server, and forbidden.