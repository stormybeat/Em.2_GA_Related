
### No mini-modding.

It gets in the way of mods doing our job. If you're not a mod, you do not have the power to moderate effectively. [Example of mini-modding and how it's ineffective on the Hypixel forums.](https://hypixel.net/threads/3370860/)